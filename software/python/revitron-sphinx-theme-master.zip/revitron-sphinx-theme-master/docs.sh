!# /bin/sh

npm run build
cd docs
make html
cd ..
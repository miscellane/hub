<br>

# revitron-sphinx-theme
A fork of https://github.com/revitron/revitron-sphinx-theme

<br>

### Notes

* [Automatic Releases](https://github.com/marketplace/actions/automatic-releases)
* REVITRON
  * [revitron-sphinx-theme](https://github.com/revitron/revitron-sphinx-theme)
  * [REVITRON](https://github.com/revitron/revitron)

* [.travis.yml](https://docs.travis-ci.com/user/tutorial/)
* [.readthedocs.yml](https://docs.readthedocs.io/en/stable/config-file/index.html)
* [requirements.txt](https://pip.pypa.io/en/stable/reference/requirements-file-format/)

* [sphinx.locale](https://www.sphinx-doc.org/en/master/_modules/sphinx/locale.html)

<br>
<br>

<br>
<br>

<br>
<br>

<br>
<br>
